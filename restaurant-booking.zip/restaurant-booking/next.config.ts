import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  env: {
    API_URL: 'https://your-backend-url.com/api',
  },
};

export default nextConfig;
