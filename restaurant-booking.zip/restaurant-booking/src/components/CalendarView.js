import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const CalendarView = ({ onDateSelect }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const handleDateChange = (date) => {
    setSelectedDate(date);
    onDateSelect(date);
  };

  return (
    <div className="p-4">
      <h3 className="text-lg font-medium">Select a Date</h3>
      <Calendar
        onChange={handleDateChange}
        value={selectedDate}
        className="border rounded"
      />
    </div>
  );
};

export default CalendarView;
