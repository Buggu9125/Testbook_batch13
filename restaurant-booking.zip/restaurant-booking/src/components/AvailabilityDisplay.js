import { useState, useEffect } from 'react';
import axios from 'axios';

const AvailabilityDisplay = ({ date }) => {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchSlots = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`/api/availability?date=${date.toISOString().split('T')[0]}`);
        setSlots(response.data);
      } catch (error) {
        alert('Failed to fetch availability');
      } finally {
        setLoading(false);
      }
    };

    if (date) fetchSlots();
  }, [date]);

  return (
    <div className="mt-4">
      <h3 className="text-lg font-medium">Available Time Slots</h3>
      {loading ? (
        <p>Loading...</p>
      ) : slots.length ? (
        <ul className="space-y-2">
          {slots.map((slot) => (
            <li key={slot._id} className="p-2 border rounded">
              {slot.time} - {slot.guests} guests
            </li>
          ))}
        </ul>
      ) : (
        <p>No slots available</p>
      )}
    </div>
  );
};

export default AvailabilityDisplay;
