import { useState } from 'react';
import BookingForm from '../components/BookingForm';
import CalendarView from '../components/CalendarView';
import AvailabilityDisplay from '../components/AvailabilityDisplay';

export default function Home() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [bookingDetails, setBookingDetails] = useState(null);

  const handleDateSelect = (date) => setSelectedDate(date);

  const handleBookingComplete = (details) => setBookingDetails(details);

  return (
    <div className="container mx-auto p-4">
      <CalendarView onDateSelect={handleDateSelect} />
      <AvailabilityDisplay date={selectedDate} />
      <BookingForm onBookingComplete={handleBookingComplete} />
      {bookingDetails && (
        <div className="mt-4 p-4 border rounded bg-green-100">
          <h4 className="font-medium">Booking Confirmed</h4>
          <p>Date: {bookingDetails.date}</p>
          <p>Time: {bookingDetails.time}</p>
          <p>Guests: {bookingDetails.guests}</p>
          <p>Name: {bookingDetails.name}</p>
          <p>Contact: {bookingDetails.contact}</p>
        </div>
      )}
    </div>
  );
}
