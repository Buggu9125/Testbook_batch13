const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');

// Get available slots for a specific date
router.get('/', async (req, res) => {
  const { date } = req.query;

  try {
    const bookings = await Booking.find({ date });
    const bookedTimes = bookings.map((b) => b.time);
    res.json(bookedTimes);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

